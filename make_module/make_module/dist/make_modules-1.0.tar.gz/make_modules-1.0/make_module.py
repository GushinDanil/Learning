def func_for_module():
    return 'Hello World'